<?php

//programs
$programs = query("SELECT * FROM program");

