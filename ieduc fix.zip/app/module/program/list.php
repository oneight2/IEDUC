<?php 

$view_program = query("SELECT * FROM program WHERE id_program = $url[1]")[0];