<section id="about">
  <div class="container">
    <header class="section-header">
      <h3>WHY IEDUC</h3>
      <div class="text-center p-2 overflow">
        <?= $why['deskripsi'] ?>
      </div>
    </header>
   
  </div>
  </section>