<section id="testimonials" class="section-bg wow fadeInUp">
  <div class="container-fluid">
    <header class="section-header">
      <h3>Testimonials</h3>
    </header>
    <div class="text-center">
      <div class="row">
        <div class="col testi">
          <?= $video['video1'] ?>
        </div>
        <div class="col testi">
          <?= $video['video2'] ?>
        </div>
      </div>
    </div>
  </div>
</section>