<section id="about">
  <div class="container">
    <header class="section-header">
      <h3>About Us</h3>
      <div class="text-center p-2 overflow">
        <?= $profil['deskripsi'] ?>
      </div>
    </header>
   
  </div>
  </section>