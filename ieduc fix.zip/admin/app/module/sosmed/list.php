<?php 
	$sosmed = query("SELECT * FROM sosial_media")[0];

 ?>