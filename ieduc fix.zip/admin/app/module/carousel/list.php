<?php 
	$carousel = query("SELECT * FROM carousel");

 ?>