<?php 
	$gallery = query("SELECT * FROM gallery");
 ?>