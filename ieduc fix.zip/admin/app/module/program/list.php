<?php 
	$programs = query("SELECT * FROM program");
	

 ?>