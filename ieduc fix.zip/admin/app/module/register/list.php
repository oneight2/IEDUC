<?php 
	$register = query("SELECT * FROM register");
