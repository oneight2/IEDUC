<?php 
	$testimoni = query("SELECT * FROM video")[0];

 ?>