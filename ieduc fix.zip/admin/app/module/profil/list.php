<?php 
	$profil = query("SELECT * FROM profil")[0];
 ?>