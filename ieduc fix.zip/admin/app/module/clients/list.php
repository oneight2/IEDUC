<?php 
	$clients = query("SELECT * FROM clients");