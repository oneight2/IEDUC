<?php 
	$why = query("SELECT * FROM why_ieduc")[0];
 ?>